import type { IE2ETestPage } from '../types';

export class BasePage implements IE2ETestPage {
	getters = {};

	actions = {};
}
