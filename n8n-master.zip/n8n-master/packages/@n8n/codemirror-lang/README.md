# @n8n/codemirror-lang

Language support package for CodeMirror 6 in n8n

[n8n Expression Language support](./src/expressions/README.md)
